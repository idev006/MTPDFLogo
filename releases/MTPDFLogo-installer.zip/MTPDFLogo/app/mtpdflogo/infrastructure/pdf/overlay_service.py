"""Apply independent text and image overlays to PDF files."""

from __future__ import annotations

import re
import tempfile
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass, field
from io import BytesIO
from pathlib import Path

import fitz
from PIL import Image, ImageDraw, ImageFont

from mtpdflogo.application.page_ranges import PageRange, page_in_ranges, parse_page_ranges
from mtpdflogo.application.positioning import resolve_overlay_top_left
from mtpdflogo.domain.models import OverlayType, Position, PositionMode


@dataclass(frozen=True, slots=True)
class PdfOverlaySpec:
    overlay_type: OverlayType
    position: Position
    position_mode: PositionMode = PositionMode.PRESET
    x_percent: float | None = None
    y_percent: float | None = None
    text: str = ""
    asset_path: Path | None = None
    font_size: float = 32.0
    font_path: Path | None = None
    color: tuple[float, float, float] = (0.0, 0.0, 0.0)
    opacity: float = 1.0
    rotation: int = 0
    width_percent: float = 12.0
    margin_pt: float = 18.0
    enabled: bool = True
    z_index: int = 0


@dataclass(frozen=True, slots=True)
class PageTextRule:
    keyword: str
    min_occurrences: int = 1
    max_occurrences: int | None = None
    case_sensitive: bool = False
    use_regex: bool = False
    page_ranges: str = ""
    _compiled_regex: re.Pattern[str] | None = field(
        default=None,
        init=False,
        repr=False,
        compare=False,
    )
    _parsed_page_ranges: tuple[PageRange, ...] | None = field(
        default=None,
        init=False,
        repr=False,
        compare=False,
    )
    _searchable_keyword: str | None = field(
        default=None,
        init=False,
        repr=False,
        compare=False,
    )

    def normalized_pattern(self) -> str:
        return unicodedata.normalize("NFKD", self.keyword)

    def count_occurrences(self, text: str) -> int:
        if not self.keyword.strip():
            return 0
        if self.use_regex:
            content = unicodedata.normalize("NFKD", text)
            count = 0
            for _match in self.compiled_regex().finditer(content):
                count += 1
                if self.max_occurrences is not None and count > self.max_occurrences:
                    return count
            return count
        content = _searchable_text(text, self.case_sensitive)
        return _count_keyword_occurrences(
            content,
            self.searchable_keyword(),
            stop_after=self.max_occurrences,
        )

    def compiled_regex(self) -> re.Pattern[str]:
        """Return a cached regex matching the normalized PDF text layer."""
        if not self.use_regex:
            raise ValueError("compiled_regex is only available when use_regex=True")
        if self._compiled_regex is None:
            flags = 0 if self.case_sensitive else re.IGNORECASE
            object.__setattr__(
                self,
                "_compiled_regex",
                re.compile(self.normalized_pattern(), flags),
            )
        return self._compiled_regex

    def searchable_keyword(self) -> str:
        """Return a cached plain keyword normalized the same way pages are searched."""
        if self._searchable_keyword is None:
            object.__setattr__(
                self,
                "_searchable_keyword",
                _searchable_text(self.keyword, self.case_sensitive),
            )
        return self._searchable_keyword

    def matches(self, text: str) -> bool:
        if not self.keyword.strip():
            return True
        count = self.count_occurrences(text)
        if count < self.min_occurrences:
            return False
        if self.max_occurrences is not None and count > self.max_occurrences:
            return False
        return True

    def matches_page(self, page_number: int) -> bool:
        return page_in_ranges(page_number, self.parsed_page_ranges())

    def parsed_page_ranges(self) -> tuple[PageRange, ...]:
        if self._parsed_page_ranges is None:
            object.__setattr__(
                self,
                "_parsed_page_ranges",
                parse_page_ranges(self.page_ranges),
            )
        return self._parsed_page_ranges


def _searchable_text(value: str, case_sensitive: bool) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    if not case_sensitive:
        normalized = normalized.casefold()
    return "".join(normalized.split())


def _count_keyword_occurrences(
    content: str,
    keyword: str,
    *,
    stop_after: int | None,
) -> int:
    if not keyword:
        return 0
    count = 0
    start = 0
    while True:
        index = content.find(keyword, start)
        if index < 0:
            return count
        count += 1
        if stop_after is not None and count > stop_after:
            return count
        start = index + len(keyword)


def _requires_explicit_font(value: str) -> bool:
    return any(ord(character) > 127 for character in value)


def _anchor_rect(
    page_rect: fitz.Rect,
    spec: PdfOverlaySpec,
    position: Position,
    width: float,
    height: float,
    margin: float,
) -> fitz.Rect:
    x, y = resolve_overlay_top_left(
        page_width=page_rect.width,
        page_height=page_rect.height,
        overlay_width=width,
        overlay_height=height,
        position=position,
        position_mode=spec.position_mode,
        x_percent=spec.x_percent,
        y_percent=spec.y_percent,
        margin=margin,
    )
    horizontal = page_rect.x0 + x
    vertical = page_rect.y0 + y
    return fitz.Rect(horizontal, vertical, horizontal + width, vertical + height)


def _apply_text(page: fitz.Page, page_rect: fitz.Rect, spec: PdfOverlaySpec) -> None:
    _apply_text_as_image(page, page_rect, spec)


def _apply_text_as_image(
    page: fitz.Page,
    page_rect: fitz.Rect,
    spec: PdfOverlaySpec,
) -> None:
    """Render text to a transparent image so Thai/Unicode glyphs survive PDF export."""
    if not spec.text:
        return
    scale = 3
    if _requires_explicit_font(spec.text) and (
        spec.font_path is None or not spec.font_path.exists()
    ):
        raise FileNotFoundError("Unicode/Thai text overlay requires a bundled font")
    font = (
        ImageFont.truetype(str(spec.font_path), max(1, round(spec.font_size * scale)))
        if spec.font_path and spec.font_path.exists()
        else ImageFont.load_default()
    )
    padding = 12 * scale
    probe = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
    draw = ImageDraw.Draw(probe)
    bbox = draw.multiline_textbbox((padding, padding), spec.text, font=font, spacing=4 * scale)
    left = min(0, bbox[0] - padding)
    top = min(0, bbox[1] - padding)
    right = max(padding, bbox[2] + padding)
    bottom = max(padding, bbox[3] + padding)
    image = Image.new(
        "RGBA",
        (max(1, right - left), max(1, bottom - top)),
        (0, 0, 0, 0),
    )
    draw = ImageDraw.Draw(image)
    color = tuple(round(channel * 255) for channel in spec.color)
    draw.multiline_text(
        (padding - left, padding - top),
        spec.text,
        font=font,
        fill=(*color, round(255 * spec.opacity)),
        spacing=4 * scale,
    )
    image = image.rotate(-spec.rotation, expand=True, resample=Image.Resampling.BICUBIC)
    stream = BytesIO()
    image.save(stream, format="PNG")
    width = image.width / scale
    height = image.height / scale
    rect = _anchor_rect(page_rect, spec, spec.position, width, height, spec.margin_pt)
    page.insert_image(rect, stream=stream.getvalue(), overlay=True)


def _apply_image(
    page: fitz.Page,
    page_rect: fitz.Rect,
    spec: PdfOverlaySpec,
    image_xrefs: dict[tuple[Path, float, int], int],
) -> None:
    if spec.asset_path is None or not spec.asset_path.exists():
        raise FileNotFoundError(f"Logo asset not found: {spec.asset_path}")
    with Image.open(spec.asset_path) as source_image:
        image = source_image.convert("RGBA")
        target_width = max(1, round(page_rect.width * spec.width_percent / 100))
        target_height = max(1, round(target_width * image.height / image.width))
        image = image.resize((target_width, target_height), Image.Resampling.LANCZOS)
        if spec.opacity < 1.0:
            alpha = image.getchannel("A").point(lambda value: round(value * spec.opacity))
            image.putalpha(alpha)
        if spec.rotation % 360:
            image = image.rotate(-spec.rotation, expand=True, resample=Image.Resampling.BICUBIC)
    width = image.width
    height = image.height
    rect = _anchor_rect(page_rect, spec, spec.position, width, height, spec.margin_pt)
    cache_key = (spec.asset_path, round(spec.opacity, 4), spec.rotation, round(width, 2))
    xref = image_xrefs.get(cache_key)
    if xref is None:
        stream = BytesIO()
        image.save(stream, format="PNG")
        xref = page.insert_image(rect, stream=stream.getvalue())
        image_xrefs[cache_key] = xref
    else:
        page.insert_image(rect, xref=xref, overlay=True)


def apply_overlays(
    source: Path,
    destination: Path,
    overlays: list[PdfOverlaySpec],
    page_text_rule: PageTextRule | None = None,
    cancel_check: Callable[[], bool] | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> None:
    """Create one marked PDF from one source PDF without combining files."""
    if source.resolve() == destination.resolve():
        raise ValueError("destination must not overwrite the source PDF")
    destination.parent.mkdir(parents=True, exist_ok=True)
    active = sorted((item for item in overlays if item.enabled), key=lambda item: item.z_index)
    with fitz.open(source) as document:
        image_xrefs: dict[tuple[Path, float, int], int] = {}
        total_pages = document.page_count
        for page_number, page in enumerate(document, 1):
            if cancel_check and cancel_check():
                raise RuntimeError("batch cancelled")
            page_rect = page.rect
            should_apply = page_text_rule is None or (
                page_text_rule.matches_page(page_number)
                and page_text_rule.matches(page.get_text("text"))
            )
            if should_apply:
                for spec in active:
                    if spec.overlay_type is OverlayType.TEXT:
                        _apply_text(page, page_rect, spec)
                    else:
                        _apply_image(page, page_rect, spec, image_xrefs)
            if progress_callback:
                progress_callback(page_number, total_pages)
        with tempfile.NamedTemporaryFile(
            prefix=f".{destination.stem}-",
            suffix=".tmp.pdf",
            dir=destination.parent,
            delete=False,
        ) as temporary:
            temporary_path = Path(temporary.name)
        try:
            document.save(temporary_path, deflate=True, garbage=0)
            temporary_path.replace(destination)
        finally:
            temporary_path.unlink(missing_ok=True)
